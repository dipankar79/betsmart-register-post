<?php

add_action( 'init', 'bsr_create_dir' );

function bsr_create_dir(){	

	$dirs = array( BSR_FILES_DIR, BSR_FILES_DOWNLOAD_DIR );

	foreach($dirs as $dir){
		// create if not created already
		if(!is_dir($dir)){
			// create
			@mkdir( $dir );
			// mode
			@chmod( $dir , 0777 );					
		}		
		// no index.html
		$index_file = $dir . BSR_DS . 'index.html';
		// check existence
		if(!file_exists($index_file)){
			// content
			$index_content = "<html><head><title>403 Forbidden</title></head><body><div>Directory access is forbidden.</div></body></html>";
			// save
			@file_put_contents($index_file, $index_content);
		}
	}
}

//function bsr_download1( $file_name = null ) {
if(!empty($_REQUEST['download_id'])) {
	//$file_name=$_REQUEST['download_id'].'.pdf';
	$download_id=$_REQUEST['download_id'];
	$file_name = get_post_meta( $download_id, 'wp_custom_attachment_newname', true );

	ignore_user_abort(true);
	set_time_limit(0); // disable the time limit for this script
	 
	$path = BSR_FILES_DOWNLOAD_DIR; //"/absolute_path_to_your_files/"; // change the path to fit your websites document structure
	 
	$dl_file = preg_replace("([^\w\s\d\-_~,;:\[\]\(\).]|[\.]{2,})", '', $file_name); // simple file name validation
	$dl_file = filter_var($dl_file, FILTER_SANITIZE_URL); // Remove (more) invalid characters
	$fullPath = $path.$dl_file;
	 
	if ($fd = fopen ($fullPath, "r")) {
	    $fsize = filesize($fullPath);
	    $path_parts = pathinfo($fullPath);
	    $ext = strtolower($path_parts["extension"]);
	    switch ($ext) {
	        case "pdf":
	        header("Content-type: application/pdf");
	        header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\""); // use 'attachment' to force a file download
	        break;

	        case "mp3":
	        header("Content-type: audio/mpeg");
	        header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\""); // use 'attachment' to force a file download
	        break;
	        // add more headers for other content types here
	        default;
	        header("Content-type: application/octet-stream");
	        header("Content-Disposition: filename=\"".$path_parts["basename"]."\"");
	        break;
	    }
	    header("Content-length: $fsize");
	    header("Cache-control: private"); //use this to open files directly
	    while(!feof($fd)) {
	        $buffer = fread($fd, 2048);
	        echo $buffer;
	    }
	}
	fclose ($fd);
	exit;
//}
}


function bsr_download( $atts ) {
	$download_id = $atts['download_id'];	

	$file_realname = get_post_meta( $download_id, 'wp_custom_attachment_realname', true );
	$file_newname = get_post_meta( $download_id, 'wp_custom_attachment_newname', true );
	$filename = current(explode(".", $file_newname));

	//return '<a href="'.BSR_PLUGIN_URL.'brs_helper.php?download_id='.$download_id.'"> Click here ( '. $file_realname .' )</a>';	
	return '<a href="'.BSR_PLUGIN_URL.'brs_helper.php?download_id='.$download_id.'"> Click here </a>';	
}
add_shortcode( 'bsrdownload', 'bsr_download' );

function bsr_wp_nav_menu_args( $args = '' ) {
	global $post;
    $post_slug=$post->post_name;

    if(! is_user_logged_in() )  { 
?>
    	<style>
    		/*#menu-item-1992 { For Dev server*/
    		#menu-item-2001 {
		        display:none;    		
		    }	
		   /* #menu-item-2080	 { For Dev server*/
		    #menu-item-2002	 {
		    	display:none;
		    }   
       
        </style>
<?php
    } else {

?>
	
	<style>
		.mgm_rss_token_container {
	        display:none;
	    }	
	    .mgm_mmdetails_head {
	    	 display:none;
	    }	

	    div.mgm_mmdetails_wrap > div.mgm_mmdetails_row:not(:last-child):last-of-type
		{
		   display:none;
		}   
       
    </style>
    <?php if('membership-details' == $post_slug) {  ?>
    <script type="text/javascript">
    	jQuery( document ).ready(function() {
		   // alert('xxxxx');
		   jQuery('.mgm_mmdetails_field_description a').text(function(index,text){
			    return text.replace('Upgrade','Resubscribe');
			});
		});
    </script>
    <?php } ?>

<?php
    }

   
}
add_action( 'wp_head', 'bsr_wp_nav_menu_args' );


// Our filter callback function 60, :664 
function brs_email_payment_receipt_status_callback($enabled, $context, $user_email ) {

    if(  'membership_purchase' == $context ) {
        // for active status ONLY
        // fetch member
        // $user = get_user_by('email', $user_email);
        // $member = mgm_get_member( $user->ID );
        // if( $member->status == MGM_STATUS_ACTIVE ){
        //   return false;
        // }
        
        return false;
    }

    // default true
    return $enabled;
   
}
add_filter( 'mgm_notify_user', 'brs_email_payment_receipt_status_callback', 10, 3 );