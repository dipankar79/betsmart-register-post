<?php
add_action( 'init', 'bsr_members_post' );
/**
 * Register a book post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function bsr_members_post() {
	$labels = array(
		'name'               => _x( 'Member Post', 'post type general name', 'mgm' ),
		'singular_name'      => _x( 'Member Post', 'post type singular name', 'mgm' ),
		'menu_name'          => _x( 'Member Post', 'admin menu', 'mgm' ),
		'name_admin_bar'     => _x( 'Member Post', 'add new on admin bar', 'mgm' ),
		'add_new'            => _x( 'Add New', 'Member Post', 'mgm' ),
		'add_new_item'       => __( 'Add New Member Post', 'mgm' ),
		'new_item'           => __( 'New Member Post', 'mgm' ),
		'edit_item'          => __( 'Edit Member Post', 'mgm' ),
		'view_item'          => __( 'View Member Post', 'mgm' ),
		'all_items'          => __( 'All Member Post', 'mgm' ),
		'search_items'       => __( 'Search Member Post', 'mgm' ),
		'parent_item_colon'  => __( 'Parent Member Post:', 'mgm' ),
		'not_found'          => __( 'No Member Post found.', 'mgm' ),
		'not_found_in_trash' => __( 'No Member Post found in Trash.', 'mgm' )
	);

	$args = array(
		'labels'             => $labels,
        'description'        => __( 'Description.', 'mgm' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'member-post' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => true,
		'menu_position'      => null,
		'supports'           => array( 'title' ),
		'taxonomies'         => array( 'category')
	);

	register_post_type( 'member-post', $args );
}

add_action('admin_menu', 'bsr_add_settings_pages');


function bsr_add_settings_pages() {
    add_submenu_page('edit.php?post_type=member-post', __('Advanced Settings','mgm'), __('Advanced Settings','mgm'), 'manage_options', 'bsr-advanced-settings', 'bsr_advanced_settings_page');
}

function bsr_advanced_settings_page () {
	load_template( dirname( __FILE__ ) . '/admin/bsr_advanced_settings_page.php' );
}

function bsr_create_taxonomy() {

	$blinkers_off = array(        
        'description' => 'Blinkers Off',
        'slug' => 'blinkers-off',
        'category_parent' => ''
        );
	wp_insert_term( 'Blinkers Off', 'category', $blinkers_off );

	$rated_market = array(        
        'description' => 'Rated Markets',
        'slug' => 'rated-market',
        'category_parent' => ''
        );
	wp_insert_term( 'Rated Markets', 'category', $rated_market );

	$punting_education = array(        
        'description' => 'Punting Education Library',
        'slug' => 'punting-education-library',
        'category_parent' => ''
        );
	wp_insert_term( 'Punting Education Library', 'category', $punting_education );

	$meeting_preview = array(        
        'description' => 'Meeting Previews',
        'slug' => 'meeting-preview',
        'category_parent' => ''
        );
	wp_insert_term( 'Meeting Previews', 'category', $meeting_preview );

	$track_pattern_analysis = array(        
        'description' => 'Track Pattern Analysis',
        'slug' => 'track-pattern-analysis',
        'category_parent' => ''
        );
	wp_insert_term( 'Track Pattern Analysis', 'category', $track_pattern_analysis );

	// __________________ For Chile ________________________

	$category_id = get_term_by('slug', 'punting-education-library', 'category');


	

	/*$principles_punting_success_audio = array(        
        'description' => 'Principles of punting success audio',
        'slug' => 'principles-punting-success-audio',
        'parent' => $category_id->term_id
        );
	wp_insert_term( 'Principles of punting success audio', 'category', $principles_punting_success_audio );*/

	$nature_of_betting = array(        
        'description' => 'Nature of Betting',
        'slug' => 'nature-of-betting',
        'parent' => $category_id->term_id
        );
	wp_insert_term( 'Nature of Betting', 'category', $nature_of_betting );

	$racing_form_factors = array(        
        'description' => 'Racing Form & Factors',
        'slug' => 'racing-form-factors',
        'parent' => $category_id->term_id
        );
	wp_insert_term( 'Racing Form & Factors', 'category', $racing_form_factors );

	$punting_strategy = array(        
        'description' => 'Punting Strategy',
        'slug' => 'punting-strategy',
        'parent' => $category_id->term_id
        );
	wp_insert_term( 'Punting Strategy', 'category', $punting_strategy );

	$money_management = array(        
        'description' => 'Money Management',
        'slug' => 'money-management',
        'parent' => $category_id->term_id
        );
	wp_insert_term( 'Money Management', 'category', $money_management );

	$punting_psychology = array(        
        'description' => 'Punting Psychology',
        'slug' => 'punting-psychology',
        'parent' => $category_id->term_id
        );
	wp_insert_term( 'Punting Psychology', 'category', $punting_psychology );

	

	
	$page_exists = get_page_by_title( 'Latest Articles' );

    if( $page_exists == null ) {
    	$bsr_post  = array( 'post_title'     => 'Latest Articles',
                   'post_type'      => 'page',
                   'post_name'      => 'latest-articles',
                   'post_content'   => 'Latest Articles',
                   'post_status'    => 'publish',
                   'comment_status' => 'closed',
                   'ping_status'    => 'closed',
                   'post_author'    => 1,
                   'menu_order'     => 0 );

		$Page_ID = wp_insert_post( $bsr_post, FALSE ); 
	// Get Post ID - FALSE to return 0 instead of wp_error.
	}

	$page_exists_access = get_page_by_title( 'Member Area Unsubscribed' );

    if( $page_exists_access == null ) {

    	$contant_area = '<p style="font-size:20px"><strong>You have been unsubscribed from Btesmart Racing Services.<br> To continue our services please <a href="#">click here</a> to Resubscribe.</strong> </p>';

    	$bsr_post_access  = array( 'post_title'     => 'Member Area Unsubscribed',
		                   'post_type'      => 'page',
		                   'post_name'      => 'member-area-unsubscribed',
		                   'post_content'   => $contant_area,
		                   'post_status'    => 'publish',
		                   'comment_status' => 'closed',
		                   'ping_status'    => 'closed',
		                   'post_author'    => 1,
		                   'menu_order'     => 0 );

		$Page_ID_access = wp_insert_post( $bsr_post_access, FALSE ); 
	// Get Post ID - FALSE to return 0 instead of wp_error.
	}



	
    
}
add_action( 'init', 'bsr_create_taxonomy' );