<?php

if('submit' == $_POST['action']) {
	$data = array( 'bsr_member_area_description' =>$_POST['bsr_description'] );
	$data_serialize = serialize( $data );
	update_option( 'bsr_advance_settings', $data_serialize );

	wp_redirect( admin_url( 'edit.php?post_type=member-post&page=bsr-advanced-settings' ) );
		exit;
}
$advance_value = unserialize (get_option( 'bsr_advance_settings' ) );


?>
<form name="post" method="post"  id="post">
<div id="poststuff"> 
<div id="post-body" class="metabox-holder columns-2">

	<div id="postbox-container-2" class="postbox-container">
		<div id="normal-sortables" class="meta-box-sortables ui-sortable">
			<div id="" class="postbox">
				<h3 class="hndle"> <span>Members Area Description</span> </h3>
				<div class="inside">
					<h2><label  for="title">Enter desctiption here</label> </h2>
					<textarea name="bsr_description" rows="4" cols="50"><?php if(!empty($advance_value['bsr_member_area_description'])) { echo $advance_value['bsr_member_area_description']; } ?></textarea>
					<br class="clear">
					<button id="submit" type="submit" name="action" value="submit" class="button button-primary button-large">Submit</button>
				</div>
			</div>
			<!-- <div id="" class="postbox">
				<h3 class="hndle"> <span>Another Metabox</span> </h3>
				<div class="inside">
					Add something here
				</div>
			</div> -->
		</div>
	</div>
	<!-- /MAIN -->
</div><!-- /post-body --> <br class="clear"> </div><!-- /poststuff -->
</form>