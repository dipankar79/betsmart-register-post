<?php
/*
Plugin Name: Betsmart Register Post
Plugin URI: http://sologicsolutions.com/extend/plugins/betsmart-register-post
Description: Betsmart Register Post
Author: Sologic Solutions 
Version: 1.0
Author URI: http://sologicsolutions.com/
*/
ob_start();
/**
 * Load callback
 */
function bsr_plugin_loaded(){
	// plugin	
    $plugin_name = trailingslashit('betsmart-register-post/betsmart-register-post.php');
	
	// register activate
	register_activation_hook($plugin_name, 'bsr_activate');
	
	// register deactivate
	register_deactivation_hook($plugin_name, 'bsr_deactivate');
	
	//activate
	bsr_activate();
	
}
add_action('plugins_loaded',  'bsr_plugin_loaded');

/**
 * Activate callback
 */
function bsr_activate(){
	global $wpdb;
	
	define('BSR_DS'                 , DIRECTORY_SEPARATOR);

	// Dirs
	define( 'BSR_PLUGIN_DIR', WP_PLUGIN_DIR . '/betsmart-register-post/' );
	define( 'BSR_PLUGIN_URL', WP_PLUGIN_URL . '/betsmart-register-post/' );

	// wp uploads dir
	if( ! defined('WP_UPLOAD_DIR') ){
		define('WP_UPLOAD_DIR'            , WP_CONTENT_DIR . BSR_DS . 'uploads' . BSR_DS );
	}

	// BSR files
	define('BSR_FILES_DIR'                , WP_UPLOAD_DIR . 'bsr' . BSR_DS);		
	define('BSR_FILES_URL'                , WP_UPLOAD_URL . 'bsr/' );	

	// download files
	define('BSR_FILES_DOWNLOAD_DIR'       , BSR_FILES_DIR . 'downloads' . BSR_DS);		
	define('BSR_FILES_DOWNLOAD_URL'       , BSR_FILES_URL . 'downloads/' );	

	// images
	define('BSR_FILES_IMAGES_DIR'       , BSR_PLUGIN_DIR . 'images' . BSR_DS);		
	define('BSR_FILES_IMAGES_URL'       , BSR_PLUGIN_URL . 'images/' );	

	
	@include( 'bsr_custom_post.php' );
	@include( 'bsr_add_meta_box.php' );
	@include( 'bsr_helper.php' );	
	
}

/**
 * Deactivate callback
 */
function bsr_deactivate(){	
	// what to do
}