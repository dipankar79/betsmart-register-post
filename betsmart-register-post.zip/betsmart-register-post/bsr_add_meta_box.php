<?php
function add_custom_meta_boxes() {
 
    // Define the custom attachment for posts
    add_meta_box(
        'wp_custom_attachment',
        'Custom Attachment',
        'wp_custom_attachment',
        'member-post'
    );  
 
} // end add_custom_meta_boxes
add_action('add_meta_boxes', 'add_custom_meta_boxes');

function wp_custom_attachment() {
 
    wp_nonce_field(plugin_basename(__FILE__), 'wp_custom_attachment_nonce');
     
    $html = '<p class="description">';
    $html .= 'Upload your PDF or audio file here.';
    $html .= '</p>';
    $html .= '<input type="file" id="wp_custom_attachment" name="wp_custom_attachment" value="" size="25" />';
   
    echo $html;

     $pdf_file_name = get_post_meta(get_the_ID(), 'wp_custom_attachment_newname', true);
     $pdf_file_realname = get_post_meta(get_the_ID(), 'wp_custom_attachment_realname', true);
     if(!empty($pdf_file_name)) {
     	$pdf_file_path = BSR_FILES_DOWNLOAD_URL.$pdf_file_name;
     	
     	echo '<br><a href="'.$pdf_file_path.'">Download PDF or Audio Here ( '. $pdf_file_realname .' )</a>';
     }
     
 
} // end wp_custom_attachment

function save_custom_meta_data($id) {

    /* --- security verification --- */
    if(!wp_verify_nonce($_POST['wp_custom_attachment_nonce'], plugin_basename(__FILE__))) {
      return $id;
    } // end if
       
    if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
      return $id;
    } // end if
       
    if('member-post' == $_POST['post_type']) {
      if(!current_user_can('edit_page', $id)) {
        return $id;
      } // end if
    } else {
        if(!current_user_can('edit_page', $id)) {
            return $id;
        } // end if
    } // end if
    /* - end security verification - */
     
    // Make sure the file array isn't empty
    if(!empty($_FILES['wp_custom_attachment']['name'])) {
         
        // Setup the array of supported file types. In this case, it's just PDF.
        $supported_types = array('application/pdf','audio/mp3','audio/mpeg');
         
        // Get the file type of the upload
        $arr_file_type = wp_check_filetype(basename($_FILES['wp_custom_attachment']['name']));
        $uploaded_type = $arr_file_type['type'];

        //echo "sssssssssssssssss".$uploaded_type;
        //exit();
         
        // Check if the type is supported. If not, throw an error.
        if(in_array($uploaded_type, $supported_types)) {


        	$realname = $_FILES['wp_custom_attachment']['name'];  
			// random filename
			$uniquename = substr(microtime(),2,8);
			// paths
			$oldname = strtolower($realname);
			$newname = preg_replace('/(.*)\.(.*)$/i', $uniquename.'.$2', $oldname);
			// keep file name
			// $realname = wp_unique_filename(MGM_FILES_DOWNLOAD_DIR, $realname);	
			// path		
			$filepath = BSR_FILES_DOWNLOAD_DIR . $newname;

			@ini_set('max_execution_time', 	'3600');
			@ini_set('upload_max_filesize', 	'1000M');
			@ini_set('post_max_size', 		'1000M');			
			// upload
			if(@move_uploaded_file($_FILES['wp_custom_attachment']['tmp_name'], $filepath)){	
				// permission
				@chmod($filepath, 0755);
				//add_post_meta($id, 'wp_custom_attachment', $newname);
                update_post_meta($id, 'wp_custom_attachment_newname', $newname); 
                update_post_meta($id, 'wp_custom_attachment_realname', $realname); 				
				// set download_file				
				
			} else {
				wp_die('There was an error uploading your file.');
			}
 
           /* // Use the WordPress API to upload the file
            $upload = wp_upload_bits($_FILES['wp_custom_attachment']['name'], null, file_get_contents($_FILES['wp_custom_attachment']['tmp_name']));
     
            if(isset($upload['error']) && $upload['error'] != 0) {
                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
            } else {
                add_post_meta($id, 'wp_custom_attachment', $upload);
                update_post_meta($id, 'wp_custom_attachment', $upload);     
            } // end if/else*/
 
        } else {
            wp_die("The file type that you've uploaded is not a PDF.");
        } // end if/else
         
    } // end if
     
} // end save_custom_meta_data
add_action('save_post', 'save_custom_meta_data');


function update_edit_form(  ) {	
    	echo ' enctype="multipart/form-data"';	
} // end update_edit_form
add_action('post_edit_form_tag', 'update_edit_form');